import React from 'react';
import axios from 'axios'
import {useState} from "react";

const Registro =(props) => {

    const [username,setUsername]= useState();
    const [pswd, setPswd] = useState();
    const [email, setEmail] = useState();

    const post = (url)=>{
        axios.post(url,{'username':username, 'password':pswd, 'email':email}).then(response=>{
            console.log(response.data)
        })
    }

    return(
        <div>

            <input type="username" name="username" onChange={e=>setUsername(e.target.value)}/>
            <input type="password" name="Password" onChange={e=>setPswd(e.target.value)}/>
            <input type="email" name="email" onChange={e => setEmail(e.target.value)}/>

         <button onClick={()=>{
             console.log('datos cargados')
             post('http://localhost:8000/api/v1/registro/usuarios/')
        }
        }>Registrarse</button>
        </div>
    )    
    
}
export default Registro;