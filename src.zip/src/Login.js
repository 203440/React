import React from 'react';
import axios from 'axios'
import {useState} from "react";
const Login =(props) => {

    const [username,setUsername]= useState();
    const [pswd, setPswd] = useState();

    const post = (url)=>{
        axios.post(url,{'username':username, 'password':pswd}).then(response=>{
            console.log(response.data)
        })
    }

    return(
        <div>
         <input type="email" name="correo" onChange={e=>setUsername(e.target.value)}/>
         <input type="password" name="Password" onChange={e=>setPswd(e.target.value)}/>
         <button onClick={()=>{
             console.log('datos cargados')
             post('http://localhost:8000/api/v1/login/')
        }
        }>Iniciar Sesion</button>
        </div>
    )    
    
}

export default Login;
