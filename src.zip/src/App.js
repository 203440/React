import './App.css';
import Login from "./Login";
import Registro from "./Registro";

function App() {
  return (
    <div className="App">
        Iniciar Sesion:
        <Login></Login>
        <br />
        <br />
        <br />
        <br />
        Registro:
        <Registro></Registro>

    </div>
  );
}

export default App;
